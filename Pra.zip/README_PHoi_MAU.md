# Bài thực hành phối màu đơn tông

## Phiên bản 1 - Xanh CodeGym

- Bậc 1: `#00ADEE`
- Bậc 2: `#00B2EF`
- Bậc 4: `#00BFF2` - nền chính
- Bậc 7: `#8DD7F7` - nền nội dung
- Bậc 9: `#C6E9FA` - nền footer
- Chữ: `#000000`

File phối màu: `monochrome-codegym.css`

## Phiên bản 2 - Gợi ý bảng màu đơn tông khác

Có thể sao chép `monochrome-codegym.css` và đổi sang một bảng tím đơn tông:

- Bậc 1: `#6A1B9A`
- Bậc 2: `#7B1FA2`
- Bậc 4: `#9C27B0`
- Bậc 7: `#CE93D8`
- Bậc 9: `#F3E5F5`

Mục tiêu là giữ nguyên cách phối: nền chính dùng bậc 4, ON SALE/PREVIEW dùng bậc 1, nội dung dùng bậc 7, footer dùng bậc 9 và chữ màu đen.
